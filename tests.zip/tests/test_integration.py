import pytest

def test_submit_order_integration(client):
    order_data = {
        "side": "buy",
        "quantity": 10,
        "price": 100,
        "order_type": "limit",
        "symbol": "AAPL"
    }
    response = client.post("/submit_order", json=order_data)
    assert response.status_code == 200

    json_response = response.json()
    assert "trades" in json_response or "trades_executed" in json_response
    assert "best_bid" in json_response

    print(json_response)
