import pytest

def test_submit_order(client):
   def sample_order_data():
    return Order(
        side="buy",
        quantity=10,
        price=100,
        order_type="limit",
        symbol="AAPL"
    )
    response = client.post("/submit_order", json=order_data)
    
    assert response.status_code == 200, f"Expected 200, got {response.status_code}. Response: {response.text}"
    
    json_response = response.json()
    assert "trades_executed" in json_response or "trades" in json_response, f"Response keys: {json_response.keys()}"

def test_order_book(client):
    response = client.get("/order_book/")
    assert response.status_code == 200
    data = response.json()
    assert "asks" in data
    assert "bids" in data

def test_cancel_order_not_found(client):
    response = client.delete("/cancel_order/nonexistent_id")
    assert response.status_code == 404
