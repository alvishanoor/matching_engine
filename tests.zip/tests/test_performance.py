import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.models import Base
from app.crud import add_order, get_order, cancel_order, get_order_book, match_orders
from app.models import Order
@pytest.fixture(scope="function")
def test_db():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(bind=engine)
    TestingSessionLocal = sessionmaker(bind=engine)
    session = TestingSessionLocal()
    try:
        yield session
    finally:
        session.close()

class OrderData:
    side = "buy"
    quantity = 10
    price = 100
    order_type = "limit"
    symbol = "AAPL"

def sample_order_data():
    return Order(
        side="buy",
        quantity=10,
        price=100,
        order_type="limit",
        symbol="AAPL"
    )

def test_add_order_performance(benchmark, test_db):
    order_data = sample_order_data()
    def run():
        add_order(test_db, order_data)
    benchmark(run)


def test_get_order_performance(benchmark, test_db):
    order = add_order(test_db, sample_order_data())
    def run():
        get_order(test_db, order.id)
    benchmark(run)

def test_cancel_order_performance(benchmark, test_db):
    order = add_order(test_db, sample_order_data())
    def run():
        cancel_order(test_db, order.id)
    benchmark(run)

def test_get_order_book_performance(benchmark, test_db):
    def run():
        get_order_book(test_db)
    benchmark(run)

def test_match_orders_performance(benchmark, test_db):
    buy_order = add_order(test_db, sample_order_data())
    sell_order_data = sample_order_data()
    sell_order_data.side = "sell"
    sell_order_data.price = 90
    sell_order = add_order(test_db, sell_order_data)
    def run():
        match_orders(test_db, buy_order)
    benchmark(run)
