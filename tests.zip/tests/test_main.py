import sys
import os
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)


def test_read_root():
    response = client.get("/")
    assert response.status_code == 200
    assert response.json() == {"message": "Welcome to Crypto Matching Engine API"}

def test_submit_order():
    order_data = {
        "symbol": "AAPL",
        "order_type": "limit",
        "side": "buy",
        "quantity": 5,
        "price": 150.0
    }
    response = client.post("/submit_order", json=order_data)
    assert response.status_code == 200
    assert "message" in response.json()

def test_get_orders():
    response = client.get("/orders")
    assert response.status_code == 200
    assert isinstance(response.json(), list)
