from sqlalchemy import Column, String, Float, Enum as SqlEnum, DateTime
import enum
import uuid
from datetime import datetime
from app.base import Base

class Side(enum.Enum):
    buy = "buy"
    sell = "sell"

class OrderType(enum.Enum):
    market = "market"
    limit = "limit"
    ioc = "ioc"
    fok = "fok"

class Order(Base):
    __tablename__ = "orders"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    symbol = Column(String, index=True)
    side = Column(SqlEnum(Side))
    quantity = Column(Float)
    price = Column(Float)
    order_type = Column(SqlEnum(OrderType))
    timestamp = Column(DateTime, default=datetime.utcnow)

class Trade(Base):
    __tablename__ = "trades"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    price = Column(Float)
    quantity = Column(Float)
    buy_order_id = Column(String)
    sell_order_id = Column(String)
    timestamp = Column(DateTime, default=datetime.utcnow)

class User(Base):
    __tablename__ = "users"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    username = Column(String, unique=True, index=True, nullable=False)
    email = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
