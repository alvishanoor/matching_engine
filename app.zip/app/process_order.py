# app/process_order.py
from sqlalchemy.orm import Session
from app.models import Order as DbOrder
from app.crud import get_all_orders, save_trade
from app.orderbook import calculate_bbo
from typing import List, Dict
import asyncio

async def process_order(db: Session, order: DbOrder) -> Dict:
    """
    Process order:
    - Save to DB
    - Run matching engine
    - Save trades
    - Return BBO
    """
    # Save order to DB
    db.add(order)
    db.commit()
    db.refresh(order)

    # Fetch all current orders
    orders = get_all_orders(db)

    # Matching engine (synchronous, wrapped in async)
    trades: List = await asyncio.to_thread(match_and_save_trades, db, orders)

    # Calculate BBO
    best_bid, best_ask = calculate_bbo(orders)

    return {"trades": trades, "best_bid": best_bid, "best_ask": best_ask}


def match_and_save_trades(db: Session, orders: list):
    """
    Blocking function to match orders and save trades.
    This is run inside asyncio.to_thread to prevent blocking.
    """
    from app.matching import match_orders  # import here to avoid circular imports

    trades = match_orders(orders)
    for trade in trades:
        save_trade(db, trade)
    return trades
