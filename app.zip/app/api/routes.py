# app/routers.py
from fastapi import APIRouter, Depends, WebSocket, HTTPException
from sqlalchemy.orm import Session
from app.schemas import OrderSchema
from app.process_order import process_order
from app.database import get_db
from app.orderbook import calculate_bbo
from app.trade_stream import manager
from app.schemas import OrderType
import asyncio
from app.models import Order as DbOrder
from app.crud import get_all_orders, save_trade
from app.matching import match_orders
from app.orderbook import calculate_bbo
from app.trade_stream import manager
import uuid

router = APIRouter()

# In-memory order book
order_book_memory = []

@router.post("/submit_order/")
async def submit_order(order: OrderSchema, db: Session = Depends(get_db)):
    if order.quantity <= 0:
        raise HTTPException(status_code=400, detail="Quantity must be positive")
    
    if order.order_type in ("limit", "ioc", "fok") and (order.price is None or order.price <= 0):
        raise HTTPException(status_code=400, detail="Price must be positive for limit/IOC/FOK orders")

    order_obj = Order(
        id=str(uuid.uuid4()),
        symbol=order.symbol,
        order_type=order.order_type.value,
        side=order.side.value,
        quantity=order.quantity,
        price=order.price if order.order_type != "market" else 0
    )

    db.add(order_obj)
    db.commit()
    db.refresh(order_obj)

    # Order matching on threadpool to prevent blocking
    trades = await asyncio.to_thread(match_orders, db, order_obj)

    for trade in trades:
        save_trade(db, trade)

    best_bid, best_ask = calculate_bbo(get_all_orders(db))

    # Broadcast trade info asynchronously to WS clients
    loop = asyncio.get_running_loop()
    for trade in trades:
        loop.create_task(manager.broadcast({
            "trade_id": trade.id,
            "symbol": order.symbol,
            "price": trade.price,
            "quantity": trade.quantity,
            "aggressor_side": order.side,
            "maker_order_id": trade.buy_order_id,
            "taker_order_id": trade.sell_order_id,
            "timestamp": trade.timestamp.isoformat()
        }))

    return {
        "message": "Order processed",
        "best_bid": best_bid,
        "best_ask": best_ask,
        "trades_executed": [t.id for t in trades]
    }


@router.delete("/cancel_order/{order_id}")
async def cancel_order(order_id: str, db: Session = Depends(get_db)):
    order = db.query(DbOrder).filter(DbOrder.id == order_id).first()
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    db.delete(order)
    db.commit()
    global order_book_memory
    order_book_memory = [o for o in order_book_memory if o.id != order_id]
    return {"message": f"Order {order_id} cancelled successfully"}

@router.get("/order_book/")
async def get_order_book():
    top_bids = sorted([o for o in order_book_memory if o.side == "buy" and o.quantity > 0], key=lambda x: -x.price)[:10]
    top_asks = sorted([o for o in order_book_memory if o.side == "sell" and o.quantity > 0], key=lambda x: x.price)[:10]
    best_bid, best_ask = calculate_bbo(order_book_memory)
    return {
        "best_bid": best_bid,
        "best_ask": best_ask,
        "bids": [{"price": b.price, "quantity": b.quantity, "id": b.id} for b in top_bids],
        "asks": [{"price": a.price, "quantity": a.quantity, "id": a.id} for a in top_asks]
    }

@router.websocket("/ws/order_book/")
async def websocket_order_book(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        while True:
            await websocket.receive_text()  # keep connection alive
    except:
        manager.disconnect(websocket)
