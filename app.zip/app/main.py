from fastapi import FastAPI, Depends, HTTPException, APIRouter, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from enum import Enum
from sqlalchemy.orm import Session
import uuid
from typing import List
import asyncio

from app import crud, models
from app.database import engine, get_db
from app.orderbook import OrderBook
from app.auth.auth_routes import router as auth_router
from app.auth.auth_bearer import JWTBearer
from app.schemas import UserCreate
from app.utils import get_hashed_password

app = FastAPI()

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Create DB tables
models.Base.metadata.create_all(bind=engine)

# Initialize order book
order_book = OrderBook()

# Auth routes
app.include_router(auth_router, prefix="/auth")
router = APIRouter()


# -------------------- USER SIGNUP --------------------
@router.post("/signup")
def signup(user: UserCreate, db: Session = Depends(get_db)):
    existing_user = crud.get_user_by_username(db, user.username)
    if existing_user:
        raise HTTPException(status_code=400, detail="Username already taken")
    hashed_password = get_hashed_password(user.password)
    db_user = models.User(
        username=user.username,
        email=user.email,
        hashed_password=hashed_password
    )
    crud.create_user(db, db_user)
    return {"message": "User registered successfully"}


app.include_router(router)


# -------------------- PROTECTED ROUTE --------------------
@app.get("/protected-route", dependencies=[Depends(JWTBearer())])
def protected():
    return {"message": "You are authenticated!"}


# -------------------- ROOT --------------------
@app.get("/")
def read_root():
    return {"message": "Welcome to Crypto Matching Engine API"}


# -------------------- GET ORDERS --------------------
@app.get("/orders")
def get_orders(db: Session = Depends(get_db)):
    return crud.get_all_orders(db)


# -------------------- GET ORDER BOOK --------------------
# GET ORDER BOOK endpoint: include best_bid and best_ask
@app.get("/order_book/")
def get_order_book_endpoint(db: Session = Depends(get_db)):
    ob = crud.get_order_book(db)
    best_bid = max((b['price'] for b in ob['bids']), default=0)
    best_ask = min((a['price'] for a in ob['asks']), default=0)
    return {"bids": ob["bids"], "asks": ob["asks"], "best_bid": best_bid, "best_ask": best_ask}


# -------------------- ENUMS & ORDER REQUEST --------------------
class Side(str, Enum):
    buy = "buy"
    sell = "sell"


class OrderType(str, Enum):
    market = "market"
    limit = "limit"
    ioc = "ioc"
    fok = "fok"


class OrderRequest(BaseModel):
    symbol: str
    order_type: OrderType
    side: Side
    quantity: float
    price: float = None


# -------------------- WEBSOCKET MANAGER --------------------
class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)

    def disconnect(self, websocket: WebSocket):
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)

    async def broadcast(self, message: dict):
        for connection in self.active_connections:
            try:
                await connection.send_json(message)
            except:
                self.disconnect(connection)


connection_manager = ConnectionManager()


# -------------------- TRADE BROADCAST --------------------
async def broadcast_trade(trade):
    message = {
        "trade_id": getattr(trade, "id", ""),
        "symbol": getattr(trade, "symbol", ""),
        "price": getattr(trade, "price", 0),
        "quantity": getattr(trade, "quantity", 0),
        "timestamp": getattr(trade, "timestamp", None).isoformat() if getattr(trade, "timestamp", None) else "",
        "aggressor_side": getattr(trade, "side", ""),
        "maker_order_id": getattr(trade, "buy_order_id", ""),
        "taker_order_id": getattr(trade, "sell_order_id", "")
    }
    await connection_manager.broadcast(message)


# -------------------- WEBSOCKET ENDPOINT --------------------
@app.websocket("/ws/order_book/")
async def order_book_ws(websocket: WebSocket):
    await connection_manager.connect(websocket)
    try:
        while True:
            await websocket.receive_text()  # keep alive
    except WebSocketDisconnect:
        connection_manager.disconnect(websocket)


# -------------------- SUBMIT ORDER --------------------
@app.post("/submit_order/")
async def submit_order(order: OrderRequest, db: Session = Depends(get_db)):
    if order.quantity <= 0:
        raise HTTPException(status_code=400, detail="Quantity must be positive")

    if order.order_type in ("limit", "ioc", "fok") and (order.price is None or order.price <= 0):
        raise HTTPException(status_code=400, detail="Price must be positive for limit/IOC/FOK orders")

    if order.order_type == "market":
        order.price = max(order.price or 0, 0)

    order_obj = models.Order(
        id=str(uuid.uuid4()),
        symbol=order.symbol,
        order_type=order.order_type.value,
        side=order.side.value,
        quantity=order.quantity,
        price=order.price if order.order_type != "market" else 0
    )

    # Save & match orders
    trades = crud.match_orders(db, order_obj)

    for trade in trades:
        crud.save_trade(db, trade)

    # Refresh order book after matching
    ob = crud.get_order_book(db)
    best_bid = max((b['price'] for b in ob['bids']), default=0)
    best_ask = min((a['price'] for a in ob['asks']), default=0)

    # Broadcast trades safely in running loop
    loop = asyncio.get_running_loop()
    for trade in trades:
        loop.create_task(broadcast_trade(trade))

    return {
        "message": "Order processed",
        "best_bid": best_bid,
        "best_ask": best_ask,
        "trades_executed": trades
    }

# -------------------- CANCEL ORDER --------------------
@app.delete("/order/{order_id}/")
def cancel_order(order_id: str, db: Session = Depends(get_db)):
    success = crud.cancel_order(db, order_id)
    if not success:
        raise HTTPException(status_code=404, detail="Order not found or cannot cancel")
    return {"message": "Order cancelled successfully"}

