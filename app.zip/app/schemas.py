from pydantic import BaseModel, EmailStr
from enum import Enum

class Side(str, Enum):
    buy = "buy"
    sell = "sell"

class OrderType(str, Enum):
    market = "market"
    limit = "limit"
    ioc = "ioc"
    fok = "fok"

class OrderSchema(BaseModel):
    side: Side
    quantity: float
    price: float = 0
    order_type: OrderType = OrderType.limit
    symbol: str

class UserCreate(BaseModel):
    username: str
    email: EmailStr
    password: str

class OrderCreate(OrderSchema):
    pass
