from app.models import Order, Trade
import uuid
from datetime import datetime

def match_orders(order_book):
    """
    Matches orders with price-time priority and handles Market, Limit, IOC, FOK.
    Updates order quantities in place and returns list of executed trades.
    """

    # Separate buy and sell orders with quantity > 0
    bids = sorted(
        [o for o in order_book if o.side == "buy" and o.quantity > 0],
        key=lambda x: (-x.price, x.timestamp)
    )
    asks = sorted(
        [o for o in order_book if o.side == "sell" and o.quantity > 0],
        key=lambda x: (x.price, x.timestamp)
    )

    trades = []

    i, j = 0, 0
    while i < len(bids) and j < len(asks):
        bid = bids[i]
        ask = asks[j]

        # Match only if prices cross
        if bid.price >= ask.price:
            trade_qty = min(bid.quantity, ask.quantity)
            trade_price = ask.price  # maker price

            # Determine order types
            bid_is_ioc = getattr(bid, 'order_type', '').lower() == 'ioc'
            bid_is_fok = getattr(bid, 'order_type', '').lower() == 'fok'
            ask_is_ioc = getattr(ask, 'order_type', '').lower() == 'ioc'
            ask_is_fok = getattr(ask, 'order_type', '').lower() == 'fok'

            # FOK logic: if full fill not possible, skip
            if (bid_is_fok and bid.quantity > ask.quantity) or (ask_is_fok and ask.quantity > bid.quantity):
                if bid_is_fok:
                    i += 1
                if ask_is_fok:
                    j += 1
                continue

            # Create trade record
            trade = Trade(
                id=str(uuid.uuid4()),
                price=trade_price,
                quantity=trade_qty,
                buy_order_id=bid.id,
                sell_order_id=ask.id,
                timestamp=datetime.utcnow()
            )
            trades.append(trade)

            # Update quantities
            bid.quantity -= trade_qty
            ask.quantity -= trade_qty

            # Remove orders if filled
            if bid.quantity <= 0:
                if bid_is_ioc and bid.quantity > 0:
                    bid.quantity = 0
                i += 1
            if ask.quantity <= 0:
                if ask_is_ioc and ask.quantity > 0:
                    ask.quantity = 0
                j += 1
        else:
            break

    # Clean zero-quantity orders
    order_book[:] = [o for o in order_book if o.quantity > 0]

    return trades
