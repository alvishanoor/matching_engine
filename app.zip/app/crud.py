from sqlalchemy.orm import Session
from sqlalchemy import desc
from passlib.context import CryptContext
import uuid
from app.models import Order, Trade, User

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def get_hashed_password(password: str) -> str:
    return pwd_context.hash(password)

def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)

def save_trade(db: Session, trade: Trade) -> Trade:
    db.add(trade)
    db.commit()
    db.refresh(trade)
    return trade

def create_user(db: Session, user: User) -> User:
    user.hashed_password = get_hashed_password(user.hashed_password)
    db.add(user)
    db.commit()
    db.refresh(user)
    return user

def get_user_by_username(db: Session, username: str) -> User:
    return db.query(User).filter(User.username == username).first()

def authenticate_user(db: Session, username: str, password: str) -> User | None:
    user = get_user_by_username(db, username)
    if not user:
        return None
    if not verify_password(password, user.hashed_password):
        return None
    return user

def add_order(db: Session, order: Order) -> Order:
    db.add(order)
    db.commit()
    db.refresh(order)
    return order

def get_order(db: Session, order_id: str) -> Order | None:
    return db.query(Order).filter(Order.id == order_id).first()

def cancel_order(db: Session, order_id: str) -> bool:
    order = get_order(db, order_id)
    if order:
        db.delete(order)
        db.commit()
        return True
    return False

def get_order_book(db: Session, limit=5):
    bids = db.query(Order).filter(Order.side == "buy").order_by(desc(Order.price), Order.id).limit(limit).all()
    asks = db.query(Order).filter(Order.side == "sell").order_by(Order.price, Order.id).limit(limit).all()

    def serialize_order(o: Order):
        return {
            "id": o.id,
            "price": max(0, o.price),
            "quantity": max(0, o.quantity),
            "order_type": o.order_type.value if hasattr(o.order_type, "value") else o.order_type,
            "side": o.side.value if hasattr(o.side, "value") else o.side,
            "symbol": o.symbol
        }

    return {
        "bids": [serialize_order(o) for o in bids],
        "asks": [serialize_order(o) for o in asks]
    }
def match_orders(db: Session, new_order: Order):
    # Fetch opposite side orders
    if new_order.side == "buy":
        if new_order.order_type == "market":
            opposite_orders = db.query(Order).filter(Order.side == "sell").order_by(Order.price, Order.id).all()
        else:
            opposite_orders = db.query(Order).filter(Order.side == "sell", Order.price <= new_order.price).order_by(Order.price, Order.id).all()
    else:
        if new_order.order_type == "market":
            opposite_orders = db.query(Order).filter(Order.side == "buy").order_by(desc(Order.price), Order.id).all()
        else:
            opposite_orders = db.query(Order).filter(Order.side == "buy", Order.price >= new_order.price).order_by(desc(Order.price), Order.id).all()

    trades = []
    remaining_qty = new_order.quantity

    # Calculate total available quantity for IOC/FOK
    total_available = sum(o.quantity for o in opposite_orders)

    # FOK: Cancel if not enough quantity
    if new_order.order_type == "fok" and total_available < remaining_qty:
        return []  # FOK cannot be filled, cancel order

    # IOC: Only fill what is immediately available
    if new_order.order_type == "ioc":
        remaining_qty = min(remaining_qty, total_available)

    # Matching loop
    for o in opposite_orders:
        if remaining_qty <= 0:
            break
        trade_qty = min(remaining_qty, o.quantity)
        trade_price = o.price

        trade = Trade(
            id=str(uuid.uuid4()),
            price=trade_price,
            quantity=trade_qty,
            buy_order_id=new_order.id if new_order.side == "buy" else o.id,
            sell_order_id=new_order.id if new_order.side == "sell" else o.id,
        )
        trades.append(trade)

        remaining_qty -= trade_qty
        o.quantity -= trade_qty

        if o.quantity <= 0:
            db.delete(o)
        else:
            db.add(o)

        db.add(trade)

    # Only add leftover for limit/market orders
    if remaining_qty > 0 and new_order.order_type in ("limit", "market"):
        new_order.quantity = remaining_qty
        db.add(new_order)

    db.commit()
    return trades

def get_all_orders(db: Session):
    return db.query(Order).all()
