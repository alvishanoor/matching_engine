from collections import deque
from sortedcontainers import SortedDict
import uuid
from datetime import datetime
from app.models import Trade 


class Order:
    def __init__(self, id, side, quantity, price, order_type, timestamp=None):
        self.id = id
        self.side = side  # "buy" or "sell"
        self.quantity = quantity
        self.price = price
        self.order_type = order_type
        self.timestamp = timestamp or datetime.utcnow()


class OrderBook:
    def __init__(self):
        self.bids = SortedDict(lambda x: -x)  # highest bid first
        self.asks = SortedDict()               # lowest ask first

    def add_order(self, order: Order):
        # Add only if quantity and price valid
        if order.quantity <= 0:
            return
        if order.price < 0:
            return
        book = self.bids if order.side == "buy" else self.asks
        if order.price not in book:
            book[order.price] = deque()
        book[order.price].append(order)

    def get_bbo(self):
        best_bid = None
        best_ask = None
        # Find best bid with quantity > 0
        for price in self.bids:
            if any(o.quantity > 0 for o in self.bids[price]):
                best_bid = price
                break
        # Find best ask with quantity > 0
        for price in self.asks:
            if any(o.quantity > 0 for o in self.asks[price]):
                best_ask = price
                break
        return best_bid, best_ask

    def match_orders(self, incoming_order: Order):
        trades = []

        if incoming_order.side == "buy":
            opposite_book = self.asks
            compare = lambda price: price <= incoming_order.price if incoming_order.price else True
        else:
            opposite_book = self.bids
            compare = lambda price: price >= incoming_order.price if incoming_order.price else True

        # FOK check
        if incoming_order.order_type == "fok":
            total_qty = 0
            for price, orders in opposite_book.items():
                if not compare(price):
                    break
                total_qty += sum(o.quantity for o in orders)
                if total_qty >= incoming_order.quantity:
                    break
            if total_qty < incoming_order.quantity:
                return []  # cancel FOK if cannot fully fill

        # Matching loop
        while incoming_order.quantity > 0 and opposite_book:
            best_price, orders_at_price = opposite_book.peekitem(0)
            if not compare(best_price):
                break

            resting_order = orders_at_price[0]
            trade_qty = min(incoming_order.quantity, resting_order.quantity)

            trade = Trade(
                id=str(uuid.uuid4()),
                price=best_price,
                quantity=trade_qty,
                buy_order_id=incoming_order.id if incoming_order.side == "buy" else resting_order.id,
                sell_order_id=incoming_order.id if incoming_order.side == "sell" else resting_order.id,
                timestamp=datetime.utcnow()
            )
            trades.append(trade)

            incoming_order.quantity -= trade_qty
            resting_order.quantity -= trade_qty

            if resting_order.quantity <= 0:
                orders_at_price.popleft()
                if not orders_at_price:
                    del opposite_book[best_price]

        # Add remaining to book if needed
        if incoming_order.quantity > 0 and incoming_order.order_type in ("limit", "market"):
            self.add_order(incoming_order)

        return trades


def calculate_bbo(orders):
    bids = [o for o in orders if o.side == "buy" and o.quantity > 0 and o.price > 0]
    asks = [o for o in orders if o.side == "sell" and o.quantity > 0 and o.price > 0]
    best_bid = max([b.price for b in bids], default=None)
    best_ask = min([a.price for a in asks], default=None)
    return best_bid, best_ask
